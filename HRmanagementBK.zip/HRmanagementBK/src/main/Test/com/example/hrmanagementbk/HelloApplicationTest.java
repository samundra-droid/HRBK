package com.example.hrmanagementbk;

import static org.junit.jupiter.api.Assertions.*;

class HelloApplicationTest {

}Assertions.assertEquals();