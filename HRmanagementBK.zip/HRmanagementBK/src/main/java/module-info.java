module com.example.hrmanagementbk {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.hrmanagementbk to javafx.fxml;
    exports com.example.hrmanagementbk;
}