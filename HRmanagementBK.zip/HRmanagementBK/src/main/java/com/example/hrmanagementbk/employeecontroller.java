package com.example.hrmanagementbk;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import java.sql.*;

public class employeecontroller {
    public TableColumn Employeeid;
    public TableColumn Employeename;
    public TableColumn Email;
    public TableColumn Salary;
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    String employeename = Employeename.getText();
    String email = Email.getText();
    String salary = Salary.getText();


    String jdbcUrl = "jdbc:mysql://localhost:3306/hrbk";
    String dbUser = "root";
    String dbPassword = "";
        try(
    Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
            dbPassword))

    {
// Execute a SQL query to retrieve data from the database
        String query = "INSERT INTO `employee`( `Employeename`, `Email`, `Salary`) VALUES ('" + employeename + "','" + email + "','" + salary + "')";
        Statement statement = connection.createStatement();
        statement.execute(query);
// Populate the table with data from the database

    } catch(
    SQLException e)

    {
        e.printStackTrace();
    }
}