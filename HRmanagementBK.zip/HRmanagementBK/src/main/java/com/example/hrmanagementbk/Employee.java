package com.example.hrmanagementbk;

public class Employee {

        private int Employeeid;
        private String Employeename;
        private String email;

        private String salary;

    public Employee(int employeeid, String employeename, String email, String salary) {
        Employeeid = employeeid;
        Employeename = employeename;
        this.email = email;
        this.salary = salary;
    }

    public int getEmployeeid() {
        return Employeeid;
    }

    public void setEmployeeid(int employeeid) {
        Employeeid = employeeid;
    }

    public String getEmployeename() {
        return Employeename;
    }

    public void setEmployeename(String employeename) {
        Employeename = employeename;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }
}

