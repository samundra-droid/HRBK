package com.example.hrmanagementbk;

public class Admin {
    private int Adminid;
    private String Adminname;
    private String Email;
    private String Password;

    public Admin(int adminid, String adminname, String email, String password) {
        Adminid = adminid;
        Adminname = adminname;
        Email = email;
        Password = password;
    }

    public int getAdminid() {
        return Adminid;
    }

    public void setAdminid(int adminid) {
        Adminid = adminid;
    }

    public String getAdminname() {
        return Adminname;
    }

    public void setAdminname(String adminname) {
        Adminname = adminname;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }
}

